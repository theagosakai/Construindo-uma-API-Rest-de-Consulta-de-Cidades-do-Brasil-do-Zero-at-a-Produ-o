# LABS

## 018_ConstruindoUmaAPIRestDeConsultaDeCidadesDoBrasilDoZeroAteAProducao
Construindo Uma API Rest De Consulta De Cidades Do Brasil Do Zero Ate A Producao. Usando Java e Spring Boots

### DESCRIÇÃO
Neste projeto você terá o desafio de desenvolver uma API Rest de consulta de cidades do Brasil com dados comparativos. Iremos navegar pelas boas práticas de Java e do Spring, popular o bando de dados Postgres e criar um serviço para o cálculo de distância entre cidades.

Java Postgre SQLSpring Boot

#### André Gomes
Lead Software Engineer, PagSeguro PagBank

https://web.digitalinnovation.one/lab/construindo-uma-api-rest-de-consulta-de-cidades-do-brasil-do-zero-ate-producao/learning/1712e293-1655-49e4-a982-9c61465bd1b8
